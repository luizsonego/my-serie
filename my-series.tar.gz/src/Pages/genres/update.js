import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Redirect } from 'react-router-dom'

const updateGenres = ({match}) => {

    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [name, setName] = useState('')
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [success, setSucces] = useState(false)
    const onChange = e => {
        setName(e.target.value)
    }
console.log(match)
    // eslint-disable-next-line react-hooks/rules-of-hooks
    useEffect(() => {
        axios.get('/api/genres/' + match.params.id).then(resp => {
            setName(resp.data.name)
        })
    }, [match.params.id])

    const save = () => {
        axios.put('/api/genres/' + match.params.id, {
            name
        })
        .then(resp => {
            setSucces(true)
        })
    }
    if (success) return (<Redirect to='/genres'></Redirect>)

    return (
        <div className="container">
            <h1>Editar Generos {name}</h1>

            <form>
                <div className="form-group">
                    <label htmlFor="name">Nome</label>
                    <input type="text" className="form-control" value={name} onChange={onChange} id="name" aria-describedby="name" />
                </div>

                <button type="button" onClick={save} className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default updateGenres