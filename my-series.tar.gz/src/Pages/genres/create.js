import React, { useState } from 'react'
import axios from 'axios'
import { Redirect } from 'react-router-dom'

const createGenres = () => {

    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [name, setName] = useState('')
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [success, setSucces] = useState(false)
    const onChange = e => {
        setName(e.target.value)
    }

    const save = () => {
        axios.post('/api/genres', {
            name
        })
        .then(resp => {
            setSucces(true)
        })
    }
    if (success) return (<Redirect to='/genres'></Redirect>)

    return (
        <div className="container">
            <h1>Criar Generos {name}</h1>

            <form>
                <div className="form-group">
                    <label htmlFor="name">Nome</label>
                    <input type="text" className="form-control" value={name} onChange={onChange} id="name" aria-describedby="name" />
                </div>

                <button type="button" onClick={save} className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default createGenres