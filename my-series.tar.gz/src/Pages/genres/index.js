import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Table, Alert } from 'reactstrap';
import { Link } from 'react-router-dom'

const Genres = () => {
    const [data, setData] = useState([])

    useEffect(() => {
        axios.get('/api/genres').then(resp => {
            setData(resp.data.data)
        })
    },[])

    const deleteGenresAction = id => {
        axios.delete('/api/genres/' + id).then(resp => {
            const itens = data.filter(item => item.id !== id)
            setData(itens)
        })
    }

    const renderTable = record => {
        return (
            <tr key={record.id}>
                {/* <th scope="row">{record.id}</th> */}
                <td>{record.name}</td>
                <td>
                    <Link to={'/genres/' + record.id}> edit </Link>
                    <Link onClick={() => deleteGenresAction(record.id)}> delete </Link>
                </td>
            </tr>
        )
    }

    if (data.length ===  0) {
        return (
            <div className="container">
                <h1>Generos</h1>
                <Alert color="warning">
                    Voce não possui generos criados !
                </Alert>
            </div>
        )
    }
    
    return (
        <div className="container">
            <h1>Generos</h1>
            <Link to="/genres/new">novo</Link>
            <Table>
                <thead>
                    <tr>
                        {/* <th>ID</th> */}
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map(renderTable)}
                </tbody>
            </Table>
        </div>
    )
}

export default Genres