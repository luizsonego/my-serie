import React, { useState }  from 'react'
import { Navbar, NavbarBrand, Collapse, Nav, NavItem, NavLink, NavbarToggler } from 'reactstrap'
import { Link } from 'react-router-dom'

const Header = () => {
    const [navBarOpen, setNavBarOpen] = useState(false)
    const toogle = () => {
        setNavBarOpen(!navBarOpen)
    }
    return (
        <Navbar color="dark" dark expand="md">
            <NavbarBrand tag={Link} to="/">Series</NavbarBrand>
            <NavbarToggler onClick={toogle}></NavbarToggler>
            <Collapse isOpen={navBarOpen} navbar>
                <Nav className="ml-auto" navbar>
                    <NavItem>
                        <NavLink tag={Link} to="/genres">Generos</NavLink>
                    </NavItem>
                </Nav>
            </Collapse>
        </Navbar>
    )
}


export default Header