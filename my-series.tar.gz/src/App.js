import React, { useState, useEffect } from 'react';
import axios from 'axios'

import { BrowserRouter as Router, Route, Switch} from 'react-router-dom'

import Header from './components/Header'
import Genres from './Pages/genres'
import NewGenres from './Pages/genres/create'
import EditGenres from './Pages/genres/update'

const Home = () => {
  return <h1>Home</h1>
}



function App() {
  // eslint-disable-next-line
  const [data, setData] = useState({})
  useEffect(() => {
    axios.get('/api').then(resp => {
      setData(resp.data)
    })
  }, [])

  return (
    <Router>
      <div>
        <Header></Header>
        <Switch>
          <Route path="/" exact component={Home}></Route>
          <Route path="/genres" exact component={Genres}></Route>
          <Route path="/genres/new" exact component={NewGenres}></Route>
          <Route path="/genres/:id" exact component={EditGenres}></Route>
        </Switch>
        {/* <pre>{JSON.stringify(data)}</pre> */}
      </div>
    </Router>
  );
}

export default App;
